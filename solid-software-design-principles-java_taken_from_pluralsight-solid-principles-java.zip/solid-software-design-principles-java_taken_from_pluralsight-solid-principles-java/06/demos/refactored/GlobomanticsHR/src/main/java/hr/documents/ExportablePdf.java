package hr.documents;

public interface ExportablePdf {
    byte[] toPdf();
}
